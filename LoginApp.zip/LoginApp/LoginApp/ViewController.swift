//
//  ViewController.swift
//  LoginApp
//
//  Created by Kibbcom on 31/05/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

